Format: 3.0 (quilt)
Source: upgrade-guard
Binary: upgrade-guard
Architecture: any
Version: 0.1.0~beta1-1~ubuntu24.04.1
Maintainer: Upgrade Guard contributors <WangodaFrancis667@users.noreply.github.com>
Homepage: https://github.com/WangodaFrancis667/upgrade-guard
Standards-Version: 4.7.0
Vcs-Browser: https://github.com/WangodaFrancis667/upgrade-guard
Vcs-Git: https://github.com/WangodaFrancis667/upgrade-guard.git
Testsuite: autopkgtest
Build-Depends: debhelper-compat (= 13), cmake, ninja-build, pkg-config, g++, libapt-pkg-dev
Package-List:
 upgrade-guard deb admin optional arch=any
Checksums-Sha1:
 0f625da70d9ab1ca6b399808e9496bd489b6a48a 43242 upgrade-guard_0.1.0~beta1.orig.tar.gz
 73137ca7f780be00c99e425acda091d58b0c01e0 2316 upgrade-guard_0.1.0~beta1-1~ubuntu24.04.1.debian.tar.xz
Checksums-Sha256:
 ab92853603a8adcc399c32cc83fe2e2dd99b353197f7067f2303e53e8a3c2e1e 43242 upgrade-guard_0.1.0~beta1.orig.tar.gz
 1fc0978f2b0499ea2a9583c261f0e4d40ddb437edc828f3fbfb7a84d71436e31 2316 upgrade-guard_0.1.0~beta1-1~ubuntu24.04.1.debian.tar.xz
Files:
 f19eea8508ec9669a23d131057b8fdfa 43242 upgrade-guard_0.1.0~beta1.orig.tar.gz
 adbc8f2c34e67c8e3ac5db03be85212d 2316 upgrade-guard_0.1.0~beta1-1~ubuntu24.04.1.debian.tar.xz
